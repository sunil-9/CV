--
-- delete table if exits
--

DROP TABLE IF EXISTS `book`;
DROP TABLE IF EXISTS `journals`;
DROP TABLE IF EXISTS `library_management_system`;
DROP TABLE IF EXISTS `staff`;
DROP TABLE IF EXISTS `students`;

--
-- Table structure for table `book`
--

CREATE  TABLE `book` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- adding data for table `book`
--

INSERT INTO `book` (`id`, `name`, `author`) VALUES
(1, 'Introducing InnoDB Cluster', 'Charles Bell'),
(2, 'MySQL and JSON: A Practical Programming Guide', 'David Stokes'),
(4, 'MySQL Connector/Python Revealed', 'Wisborg Krogh'),
(5, 'Pro MySQL NDB Cluster', 'Wisborg Krogh, Mikiya Okuno');

-- --------------------------------------------------------

--
-- Table structure for table `journals`
--

CREATE TABLE `journals` (
  `id` int(11) NOT NULL,
  `desc` varchar(100) NOT NULL,
  `book_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- adding fields to the journals table.
ALTER TABLE `journals` ADD `issued_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `staff_id`, ADD `return_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `issued_date`;



-- --------------------------------------------------------

--
-- Table structure for table `library_management_system`
--

CREATE TABLE `library_management_system` (
  `name` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- adding data for table `library_management_system`
--

INSERT INTO `library_management_system` (`name`, `phone`) VALUES
('new Library management system', 321654987344);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- adding data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `password`) VALUES
(1, 'Liberian smith', '27155bfe7fdd738af4d02fa55465e273'),
(2, 'Liberian lila', '80e08b5f9240533067c5f5e2134a6589');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 auto_increment=1
partition by range(id) (
partition p0 values less than (2),
partition p1 values less than (100),
partition p2 values less than maxvalue
);


--
-- adding data for table `students`
--

INSERT INTO `students` ( `id`,`name`, `password`) VALUES
( 1,'harry', '3b87c97d15e8eb11e51aa25e9a5770e9'),
( 2,'harry1', '3b87c97d15e8eb11e51aa25e9a5770e9'),
( 3,'harry2', '3b87c97d15e8eb11e51aa25e9a5770e9'),
( 4,'jhon', '4c25b32a72699ed712dfa80df77fc582');

--
-- adding data for table `journals`
--

INSERT INTO `journals` (`id`, `desc`, `book_id`, `student_id`, `staff_id`) VALUES
(1, 'new book issued by jhon', 1, 2, 2);


--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `journals`
--
ALTER TABLE `journals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `journals`
--
ALTER TABLE `journals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

-- creating sub table to create statement as asked in the question 4 b.
  create table book_1 like book;
create table book_2 like book;
create table tb_book (
 `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL )engine=merge union=(book_1,book_2) insert_method=last charset=utf8;

-- adding data to the tb_book table.
INSERT INTO `book_2` (`id`, `name`, `author`) VALUES
(1, 'Introducing InnoDB Cluster', 'Charles Bell'),
(2, 'MySQL and JSON: A Practical Programming Guide', 'David Stokes'),
(4, 'MySQL Connector/Python Revealed', 'Wisborg Krogh'),
(5, 'Pro MySQL NDB Cluster', 'Wisborg Krogh, Mikiya Okuno');


INSERT INTO `book_1` (`id`, `name`, `author`) VALUES
(6, 'Introducing InnoDB Cluster', 'Charles Bell'),
(7, 'MySQL and JSON: A Practical Programming Guide', 'David Stokes');



--
-- Constraints for table `journals`
--
ALTER TABLE `journals`
  ADD CONSTRAINT `journals_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `journals_ibfk_2` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

