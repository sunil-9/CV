----select statemetns for the tables
--- 4. a 
SELECT staff.name as issued_by, students.name as issued_to,book.name as book ,issued_date,return_date
from journals
RIGHT JOIN book ON book.id = journals.book_id
RIGHT JOIN staff ON staff.id = journals.staff_id
RIGHT JOIN students ON students.id = journals.student_id
WHERE students.name ='harry'
ORDER by issued_date;

----4. b sub table example

select count(*) as book1,book2 
from book_1 
JOIN (select count(*) as book2,id from book_2) as book_2 ON book_1.id = book_1.id;


--- 4. c timestamp 

SELECT book.name as book ,issued_date,return_date,CURRENT_TIMESTAMP() as today
from journals
Left JOIN book ON book.id = journals.book_id
GROUP BY book.id;

--- 4. d partition to table students when the students are more than 50
select * from information_schema.partitions where table_name='students';


