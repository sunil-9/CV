db.library.drop();
db.books.drop();
db.createCollection('library',
    {
        validator: {
            $jsonSchema: {
                bsonType: "object",
                required: ["name", "phone"],
                properties: {
                    name: {
                        bsonType: "string",
                        description: "must be a string and is required"
                    },
                    phone: {
                        bsonType: "number",
                        description: "must be a number and is required",
                        minimum: 10000000,
                        maximum: 999999999999
                    },
                }
            }
        }
    }
);

db.createCollection('books',
    {
        validator: {
            $jsonSchema: {
                bsonType: "object",
                required: ["id", "name", "author"],
                properties: {
                    id: {
                        bsonType: "number",
                        description: "must be a number and is required"
                    },
                    name: {
                        bsonType: "string",
                        description: "must be a string and is required"
                    },
                    author: {
                        bsonType: "string",
                        description: "must be a string and is required"
                    },
                }
            }
        }
    }
);
db.createCollection('journals',
    {
        validator: {
            $jsonSchema: {
                bsonType: "object",
                required: ["book","issued_by", "desc","issued_to", "issued_date", "return_date"],//issued_by is staff and issued_to is student 
                properties: {
                    book: {
                        bsonType: "string",
                        description: "must be a string and is required",

                    },
                    issued_by: {
                        bsonType: "string",
                        description: "must be a string and is required",

                    },
                    desc: {
                        bsonType: "string",
                        description: "must be a string and is required",

                    },
                    issued_to: {
                        bsonType: "string",
                        description: "must be a string and is required",

                    },
                    issued_date: {
                        bsonType: "date",
                        description: "must be a date and is required",

                    },
                    return_date: {
                        bsonType: "date",
                        description: "must be a date and is required",

                    }
                }
            }
        }
    }
);


db.library.insert({
    'name': 'new Library',
    'phone': 1234567890,
});
db.books.insert({
    'id': 1,
    'name': 'Introducing InnoDB Cluster',
    'author': 'Charles Bell',
});
db.books.insert({
    'id': 2,
    'name': 'MySQL and JSON: A Practical Programming Guide',
    'author': 'David Stokes',
});
db.books.insert({
    'id': 3,
    'name': 'MySQL Connector/Python Revealed',
    'author': 'Wisborg Krogh',
});
db.books.insert({
    'id': 4,
    'name': 'Pro MySQL NDB Cluster',
    'author': 'Wisborg Krogh, Mikiya Okuno',
});
db.books.insert({
    'id': 5,
    'name': 'MySQL Connector/C',
    'author': 'Wisborg Krogh',
});
db.journals.insert({
    book:'MySQL Connector/Python Revealed',
            issued_by: 'Liberian lila',
            issued_to: 'harry',
            desc: "new book issued by harry",
            issued_date: new Date(),
            return_date: new Date()
        
}, {upsert: true});
db.journals.insert({
    book:'1',
            issued_by: 'Liberian smith',
            issued_to: 'jhon',
            desc: "new book issued by jhon",
            issued_date: ISODate("2022-01-04T12:00:53.307Z"),
            return_date: ISODate("2022-05-04T12:00:53.307Z")
        
}, {upsert: true});



